package com.mkyong;

import java.math.BigDecimal;

public class RmCost {
	
	private String supc;
	private String prod_code;
	private String description;
	private BigDecimal last_rcvd_cost;
	private BigDecimal max_recent_cost;
	private BigDecimal average_cost;
	private String bill_um;
	private BigDecimal average_weekly_movement;
	private BigDecimal qoh;
	private BigDecimal current_weeks_market_cost;
	private BigDecimal current_margin;
	private BigDecimal next_weeks_market_cost;
	private BigDecimal next_wk_margin;
	private BigDecimal variance;
	private BigDecimal high_vendor_quote;
	private BigDecimal usbl_raw_material_override;
	private BigDecimal floor_margin;
	private BigDecimal floor;
	private String what_if;
	public String getSupc() {
		return supc;
	}
	public void setSupc(String supc) {
		this.supc = supc;
	}
	public String getProd_code() {
		return prod_code;
	}
	public void setProd_code(String prod_code) {
		this.prod_code = prod_code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public BigDecimal getLast_rcvd_cost() {
		return last_rcvd_cost;
	}
	public void setLast_rcvd_cost(BigDecimal last_rcvd_cost) {
		this.last_rcvd_cost = last_rcvd_cost;
	}
	public BigDecimal getMax_recent_cost() {
		return max_recent_cost;
	}
	public void setMax_recent_cost(BigDecimal max_recent_cost) {
		this.max_recent_cost = max_recent_cost;
	}
	public BigDecimal getAverage_cost() {
		return average_cost;
	}
	public void setAverage_cost(BigDecimal average_cost) {
		this.average_cost = average_cost;
	}
	public String getBill_um() {
		return bill_um;
	}
	public void setBill_um(String bill_um) {
		this.bill_um = bill_um;
	}
	public BigDecimal getAverage_weekly_movement() {
		return average_weekly_movement;
	}
	public void setAverage_weekly_movement(BigDecimal average_weekly_movement) {
		this.average_weekly_movement = average_weekly_movement;
	}
	public BigDecimal getQoh() {
		return qoh;
	}
	public void setQoh(BigDecimal qoh) {
		this.qoh = qoh;
	}
	public BigDecimal getCurrent_weeks_market_cost() {
		return current_weeks_market_cost;
	}
	public void setCurrent_weeks_market_cost(BigDecimal current_weeks_market_cost) {
		this.current_weeks_market_cost = current_weeks_market_cost;
	}
	public BigDecimal getCurrent_margin() {
		return current_margin;
	}
	public void setCurrent_margin(BigDecimal current_margin) {
		this.current_margin = current_margin;
	}
	public BigDecimal getNext_weeks_market_cost() {
		return next_weeks_market_cost;
	}
	public void setNext_weeks_market_cost(BigDecimal next_weeks_market_cost) {
		this.next_weeks_market_cost = next_weeks_market_cost;
	}
	public BigDecimal getNext_wk_margin() {
		return next_wk_margin;
	}
	public void setNext_wk_margin(BigDecimal next_wk_margin) {
		this.next_wk_margin = next_wk_margin;
	}
	public BigDecimal getVariance() {
		return variance;
	}
	public void setVariance(BigDecimal variance) {
		this.variance = variance;
	}
	public BigDecimal getHigh_vendor_quote() {
		return high_vendor_quote;
	}
	public void setHigh_vendor_quote(BigDecimal high_vendor_quote) {
		this.high_vendor_quote = high_vendor_quote;
	}
	public BigDecimal getUsbl_raw_material_override() {
		return usbl_raw_material_override;
	}
	public void setUsbl_raw_material_override(BigDecimal usbl_raw_material_override) {
		this.usbl_raw_material_override = usbl_raw_material_override;
	}
	public BigDecimal getFloor_margin() {
		return floor_margin;
	}
	public void setFloor_margin(BigDecimal floor_margin) {
		this.floor_margin = floor_margin;
	}
	public BigDecimal getFloor() {
		return floor;
	}
	public void setFloor(BigDecimal floor) {
		this.floor = floor;
	}
	public String getWhat_if() {
		return what_if;
	}
	public void setWhat_if(String what_if) {
		this.what_if = what_if;
	}
	
	
	}
