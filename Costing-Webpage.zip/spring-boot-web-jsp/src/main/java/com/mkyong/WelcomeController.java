package com.mkyong;

import java.util.List;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class WelcomeController {
	
	@Autowired
	public CostingDAO costingdao;
	
	@RequestMapping("/")
	public String welcome() {
		return "welcome";
	}
	@RequestMapping("/costing/margin/load")
	public List<Costing> fpMargin(){
		List<Costing> all_margin = costingdao.getfpMargin();
        return all_margin;
	}
	@RequestMapping(value="/costing/margin/update", method=RequestMethod.POST)
    public String margin_udpate(@RequestBody Costing costing) {
		int desc=costingdao.updateMargin(costing);
        return "margin values saved successfully ::.";
    }
	@RequestMapping("/costing/rmcost/load")
	public List<RmCost> fprmcost(){
		List<RmCost> all_rmcost = costingdao.getfpRmCost();
        return all_rmcost;
	}
	@RequestMapping(value="/costing/rmcost/update", method=RequestMethod.POST)
    public String rmcost_update(@RequestParam (name="supc", required=false) String supc,@RequestParam (name="last_cost",required=false)String last_cost){
		System.out.println("check");
		//String supc=requestParams.get("supc");
		BigDecimal last_rcvd_cost=new BigDecimal(last_cost);
		System.out.println("controller "+supc+"  "+last_rcvd_cost);
		int update=costingdao.updateRmCost(supc, last_rcvd_cost);
        return "Last wk MArket cost saved successfully ::."+update;
	}
}