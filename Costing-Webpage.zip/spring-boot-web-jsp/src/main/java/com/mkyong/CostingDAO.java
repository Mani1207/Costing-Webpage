package com.mkyong;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class CostingDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public static void main(String[] args) {

		}
	public List<Costing> getfpMargin() {
		String Query = "SELECT * FROM FP_Margin";
		List<Costing> costing = new ArrayList<Costing>();
		        List<Map<String, Object>> rows = jdbcTemplate.queryForList(Query);
		       
		        for (Map<String, Object> row : rows)
		        {
		             Costing costing_s = new Costing();
		             costing_s.setSupc((String)row.get("ITEM_NUM"));
		             costing_s.setProd_code((String)row.get("PROD_CODE"));
		             costing_s.setDescription((String)row.get("DESCR_1"));
		             costing_s.setBill_um((String)row.get("BILL_UM"));
		             costing_s.setQty_unit((String)row.get("QTY_UNIT"));
		             costing_s.setList((BigDecimal)row.get("LIST_PRICE"));
		             costing_s.setFloor((BigDecimal)row.get("FLOOR"));
		             costing_s.setUsbl((BigDecimal)row.get("USBL"));
		             costing_s.setM_b((String)row.get("MAKE_BUY"));
		             costing_s.setLabor((BigDecimal)row.get("LABOR"));
		             costing_s.setItem_package((BigDecimal)row.get("PACKAGE"));
		             costing_s.setOverhead((BigDecimal)row.get("OVERHEAD"));
		             costing_s.setEi_type((String)row.get("EARNED_INCOME_TYPE"));
		             costing_s.setEarned_income((BigDecimal)row.get("EARNED_INCOME"));
		             costing_s.setMarketing((BigDecimal)row.get("MARKETING"));
		             costing_s.setCorp_income((BigDecimal)row.get("CORP_INCOME"));
		             costing_s.setItem_location((String)row.get("LOCATION"));
		             costing_s.setRm1((String)row.get("RM1"));
		             costing_s.setRm2((String)row.get("RM2"));
		             costing_s.setRm3((String)row.get("RM3"));
		             costing_s.setRm4((String)row.get("RM4"));
		             costing_s.setRm5((String)row.get("RM5"));
		             costing_s.setRm1_per((BigDecimal)row.get("RM1_PERCENT"));
		             costing_s.setRm2_per((BigDecimal)row.get("RM2_PERCENT"));
		             costing_s.setRm3_per((BigDecimal)row.get("RM3_PERCENT"));
		             costing_s.setRm4_per((BigDecimal)row.get("RM4_PERCENT"));
		             costing_s.setRm5_per((BigDecimal)row.get("RM5_PERCENT"));
		             costing_s.setBlend((String)row.get("BLEND"));
		             costing_s.setUsbl_indicator((int)row.get("USBL_IND"));
		             costing_s.setPack((String)row.get("PACK"));
		             costing_s.setSize((String)row.get("SIZE"));

		             costing.add(costing_s);
		         }

		       return costing;
		       
		}
	
	public int updateMargin(Costing costing) {
		String Query =  "UPDATE FP_Margin SET PROD_CODE = '"+costing.getProd_code()+"', DESCR_1 = '"+costing.getDescription()+"', BILL_UM = '"+costing.getBill_um()+"', QTY_UNIT = '"+costing.getQty_unit()+"', LIST_PRICE = "+costing.getList()+", FLOOR = "+costing.getFloor()+", USBL = "+costing.getUsbl()+", MAKE_BUY = '"+costing.getM_b()+"', LABOR = "+costing.getLabor()+", PACKAGE = "+costing.getItem_package()+", OVERHEAD = "+costing.getOverhead()+", EARNED_INCOME_TYPE = '"+costing.getEi_type()+"', EARNED_INCOME = "+costing.getEarned_income()+", MARKETING = "+costing.getMarketing()+", CORP_INCOME = "+costing.getCorp_income()+", LOCATION = '"+costing.getItem_location()+"', RM1 = '"+costing.getRm1()+"', RM2 = '"+costing.getRm2()+"', RM3 = '"+costing.getRm3()+"', RM4 = '"+costing.getRm4()+"', RM5 = '"+costing.getRm4()+"', RM1_PERCENT = "+costing.getRm1_per()+", RM2_PERCENT = "+costing.getRm2_per()+", RM3_PERCENT = "+costing.getRm3_per()+", RM4_PERCENT = "+costing.getRm4_per()+", RM5_PERCENT = "+costing.getRm5_per()+", BLEND = '"+costing.getBlend()+"', USBL_IND = "+costing.getUsbl_indicator()+", PACK = '"+costing.getPack()+"', SIZE = '"+costing.getSize()+"' WHERE ITEM_NUM='"+costing.getSupc()+"'";
		//String Query =  "SELECT DESCRIPTION FROM FP_Margin where SUPC='0015515'";
		List<Costing> costing_ar = new ArrayList<Costing>();
		int description = jdbcTemplate.update(Query);
		return description;
	}
	public int updateRmCost(String supc,BigDecimal last_rcvd_cost) {
			System.out.println("DAO "+supc+"  "+last_rcvd_cost);
			String Query =  "UPDATE fp_marketcost SET LAST_WK_MKT_COST = "+last_rcvd_cost+" WHERE ITEM_NUM='"+supc+"'";
			//String Query =  "SELECT DESCRIPTION FROM FP_Margin where SUPC='0015515'";
			int update = jdbcTemplate.update(Query);
			return update;
	}
	public List<RmCost> getfpRmCost() {
		String Query = "call rmcost_calc";
		List<RmCost> RmCost = new ArrayList<RmCost>();
		        List<Map<String, Object>> rows = jdbcTemplate.queryForList(Query);
		       
		        for (Map<String, Object> row : rows)
		        {
		             RmCost RmCost_s = new RmCost();
		             RmCost_s.setSupc((String)row.get("supc"));
		             RmCost_s.setProd_code((String)row.get("prod_code"));
		             RmCost_s.setDescription((String)row.get("descriptionn"));
		             RmCost_s.setLast_rcvd_cost((BigDecimal)row.get("last_rcvd_cost"));
		             RmCost_s.setMax_recent_cost((BigDecimal)row.get("max_recent_cost"));
		             RmCost_s.setAverage_cost((BigDecimal)row.get("average_cost"));
		             RmCost_s.setBill_um((String)row.get("bill_um"));
		             RmCost_s.setAverage_weekly_movement((BigDecimal)row.get("average_weekly_movement"));
		             RmCost_s.setQoh((BigDecimal)row.get("qoh"));
		             RmCost_s.setCurrent_weeks_market_cost((BigDecimal)row.get("current_weeks_market_cost")); 
		             RmCost_s.setCurrent_margin((BigDecimal)row.get("current_margin"));
		             RmCost_s.setNext_weeks_market_cost((BigDecimal)row.get("next_weeks_market_cost"));
		             RmCost_s.setNext_wk_margin((BigDecimal)row.get("next_wk_margin"));
		             RmCost_s.setVariance((BigDecimal)row.get("variance"));
		             RmCost_s.setHigh_vendor_quote((BigDecimal)row.get("high_vendor_quote"));
		             RmCost_s.setUsbl_raw_material_override((BigDecimal)row.get("usbl_raw_material_override"));
		             RmCost_s.setFloor_margin((BigDecimal)row.get("floor_margin"));
		             RmCost_s.setFloor((BigDecimal)row.get("floor"));
		             RmCost_s.setWhat_if((String)row.get("what_if"));
		             RmCost.add(RmCost_s);
		         }

		       return RmCost;
		       
		}
}
