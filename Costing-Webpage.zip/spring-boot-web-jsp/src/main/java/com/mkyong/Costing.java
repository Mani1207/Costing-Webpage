package com.mkyong;

import java.math.BigDecimal;

public class Costing {
	private String supc;
	private String prod_code;
	private String description;
	private String bill_um;
	private String qty_unit;
	private BigDecimal list;
	private BigDecimal floor;
	private BigDecimal usbl;
	private String m_b;
	private BigDecimal labor;
	private BigDecimal item_package;
	private BigDecimal overhead;
	private String ei_type;
	private BigDecimal earned_income;
	private BigDecimal marketing;
	private BigDecimal corp_income;
	private String item_location;
	private String rm1;
	private String rm2;
	private String rm3;
	private String rm4;
	private String rm5;
	private BigDecimal rm1_per;
	private BigDecimal rm2_per;
	private BigDecimal rm3_per;
	private BigDecimal rm4_per;
	private BigDecimal rm5_per;
	private String blend;
	private int usbl_indicator;
	private String pack;
	private String size;
	public String getSupc() {
		return supc;
	}
	public void setSupc(String supc) {
		this.supc = supc;
	}
	public String getProd_code() {
		return prod_code;
	}
	public void setProd_code(String prod_code) {
		this.prod_code = prod_code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBill_um() {
		return bill_um;
	}
	public void setBill_um(String bill_um) {
		this.bill_um = bill_um;
	}
	public String getQty_unit() {
		return qty_unit;
	}
	public void setQty_unit(String qty_unit) {
		this.qty_unit = qty_unit;
	}
	public BigDecimal getList() {
		return list;
	}
	public void setList(BigDecimal list) {
		this.list = list;
	}
	public BigDecimal getFloor() {
		return floor;
	}
	public void setFloor(BigDecimal floor) {
		this.floor = floor;
	}
	public BigDecimal getUsbl() {
		return usbl;
	}
	public void setUsbl(BigDecimal usbl) {
		this.usbl = usbl;
	}
	public String getM_b() {
		return m_b;
	}
	public void setM_b(String m_b) {
		this.m_b = m_b;
	}
	public BigDecimal getLabor() {
		return labor;
	}
	public void setLabor(BigDecimal labor) {
		this.labor = labor;
	}
	public BigDecimal getItem_package() {
		return item_package;
	}
	public void setItem_package(BigDecimal item_package) {
		this.item_package = item_package;
	}
	public BigDecimal getOverhead() {
		return overhead;
	}
	public void setOverhead(BigDecimal overhead) {
		this.overhead = overhead;
	}
	public String getEi_type() {
		return ei_type;
	}
	public void setEi_type(String ei_type) {
		this.ei_type = ei_type;
	}
	public BigDecimal getEarned_income() {
		return earned_income;
	}
	public void setEarned_income(BigDecimal earned_income) {
		this.earned_income = earned_income;
	}
	public BigDecimal getMarketing() {
		return marketing;
	}
	public void setMarketing(BigDecimal marketing) {
		this.marketing = marketing;
	}
	public BigDecimal getCorp_income() {
		return corp_income;
	}
	public void setCorp_income(BigDecimal corp_income) {
		this.corp_income = corp_income;
	}
	public String getItem_location() {
		return item_location;
	}
	public void setItem_location(String item_location) {
		this.item_location = item_location;
	}
	public String getRm1() {
		return rm1;
	}
	public void setRm1(String rm1) {
		this.rm1 = rm1;
	}
	public String getRm2() {
		return rm2;
	}
	public void setRm2(String rm2) {
		this.rm2 = rm2;
	}
	public String getRm3() {
		return rm3;
	}
	public void setRm3(String rm3) {
		this.rm3 = rm3;
	}
	public String getRm4() {
		return rm4;
	}
	public void setRm4(String rm4) {
		this.rm4 = rm4;
	}
	public String getRm5() {
		return rm5;
	}
	public void setRm5(String rm5) {
		this.rm5 = rm5;
	}
	public BigDecimal getRm1_per() {
		return rm1_per;
	}
	public void setRm1_per(BigDecimal rm1_per) {
		this.rm1_per = rm1_per;
	}
	public BigDecimal getRm2_per() {
		return rm2_per;
	}
	public void setRm2_per(BigDecimal rm2_per) {
		this.rm2_per = rm2_per;
	}
	public BigDecimal getRm3_per() {
		return rm3_per;
	}
	public void setRm3_per(BigDecimal rm3_per) {
		this.rm3_per = rm3_per;
	}
	public BigDecimal getRm4_per() {
		return rm4_per;
	}
	public void setRm4_per(BigDecimal rm4_per) {
		this.rm4_per = rm4_per;
	}
	public BigDecimal getRm5_per() {
		return rm5_per;
	}
	public void setRm5_per(BigDecimal rm5_per) {
		this.rm5_per = rm5_per;
	}
	public String getBlend() {
		return blend;
	}
	public void setBlend(String blend) {
		this.blend = blend;
	}
	public int getUsbl_indicator() {
		return usbl_indicator;
	}
	public void setUsbl_indicator(int usbl_indicator) {
		this.usbl_indicator = usbl_indicator;
	}
	public String getPack() {
		return pack;
	}
	public void setPack(String pack) {
		this.pack = pack;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
}
